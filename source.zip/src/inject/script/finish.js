window.csgtLoaded = true;
show_modal("CSGT is ready!", "info", "");
